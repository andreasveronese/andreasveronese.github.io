const API_BASE = "http://127.0.0.1:3333";

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    try {
      if (msg?.type === "SDF_ANALYZE_PAGE") {
        const res = await fetch(`${API_BASE}/analyze`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(msg)
        });

        if (!res.ok) {
          const t = await res.text().catch(() => "");
          throw new Error(`Server error ${res.status}: ${t || res.statusText}`);
        }

        const data = await res.json();
        sendResponse({ ok: true, data });
        return;
      }

      sendResponse({ ok: false, error: "Unknown message type" });
    } catch (e) {
      sendResponse({ ok: false, error: e?.message || String(e) });
    }
  })();

  return true;
});