function text(sel) {
  const el = document.querySelector(sel);
  return el ? el.textContent.trim() : "";
}

function attr(sel, name) {
  const el = document.querySelector(sel);
  return el ? (el.getAttribute(name) || "").trim() : "";
}

function parsePriceNumber(str) {
  if (!str) return null;
  const s = String(str)
    .replace(/\u00a0/g, " ")
    .replace(/[^\d.,]/g, "")
    .trim();

  if (!s) return null;

  // "1 299,00" -> "1299,00"
  const compact = s.replace(/\s/g, "");

  // om både punkt och komma: anta komma decimal och punkt tusen
  if (compact.includes(",") && compact.includes(".")) {
    const normalized = compact.replace(/\./g, "").replace(",", ".");
    const n = Number(normalized);
    return Number.isFinite(n) ? n : null;
  }

  // annars: ersätt komma med punkt
  const n = Number(compact.replace(",", "."));
  return Number.isFinite(n) ? n : null;
}

function readJsonLdProduct() {
  const scripts = Array.from(document.querySelectorAll('script[type="application/ld+json"]'));
  for (const s of scripts) {
    const raw = s.textContent || "";
    try {
      const data = JSON.parse(raw);

      const candidates = Array.isArray(data) ? data : [data];
      for (const obj of candidates) {
        // ibland ligger Product i @graph
        const graph = obj?.["@graph"];
        const nodes = Array.isArray(graph) ? graph : [obj];

        for (const node of nodes) {
          if (!node) continue;
          const type = node["@type"];
          const isProduct = type === "Product" || (Array.isArray(type) && type.includes("Product"));
          if (!isProduct) continue;

          const name = node.name || null;

          // offers kan vara array eller objekt
          const offers = node.offers;
          const offer = Array.isArray(offers) ? offers[0] : offers;

          const price = offer?.price ?? offer?.lowPrice ?? null;
          const currency = offer?.priceCurrency ?? null;

          const parsedPrice = typeof price === "number" ? price : parsePriceNumber(price);

          return {
            name,
            price: parsedPrice,
            currency: currency || null
          };
        }
      }
    } catch {
      // ignore
    }
  }
  return null;
}

function detectCurrencyFallback(str) {
  const s = (str || "").toLowerCase();
  if (s.includes("kr") || s.includes("sek")) return "SEK";
  if (s.includes("€") || s.includes("eur")) return "EUR";
  if (s.includes("$") || s.includes("usd")) return "USD";
  return null;
}

function detectPriceFromMeta() {
  const metaAmount =
    attr('meta[property="product:price:amount"]', "content") ||
    attr('meta[itemprop="price"]', "content") ||
    attr('meta[name="price"]', "content") ||
    "";

  const metaCurrency =
    attr('meta[property="product:price:currency"]', "content") ||
    attr('meta[itemprop="priceCurrency"]', "content") ||
    attr('meta[name="currency"]', "content") ||
    "";

  const price = parsePriceNumber(metaAmount);
  const currency = metaCurrency || null;

  if (price != null) return { price, currency };

  return null;
}

function detectPriceFromDom() {
  // Vanliga selectors (fungerar på många shops)
  const candidates = [
    text('[data-testid*="price"]'),
    text('[data-test*="price"]'),
    text('[class*="price"]'),
    text('[id*="price"]'),
    text('[itemprop="price"]')
  ].filter(Boolean);

  // Ta första som faktiskt innehåller siffror
  const raw = candidates.find((t) => /\d/.test(t)) || "";
  const price = parsePriceNumber(raw);
  const currency = detectCurrencyFallback(raw);

  if (price != null) return { price, currency };

  return { price: null, currency: currency || null, raw: raw || null };
}

function getStructuredProduct() {
  const url = location.href;
  const title = document.title || "";

  const name =
    text("h1") ||
    text('[data-testid="product-name"]') ||
    text('[data-test="product-name"]') ||
    title;

  // färg (best effort)
  const color =
    text('[data-testid*="color"]') ||
    text('[data-test*="color"]') ||
    text('[class*="color"]') ||
    null;

  // 1) JSON-LD (bäst)
  const ld = readJsonLdProduct();

  // 2) Meta tags
  const meta = detectPriceFromMeta();

  // 3) DOM fallback
  const dom = detectPriceFromDom();

  const price = ld?.price ?? meta?.price ?? dom?.price ?? null;
  const currency = ld?.currency ?? meta?.currency ?? dom?.currency ?? detectCurrencyFallback(dom?.raw) ?? "SEK";

  const pageText = (document.body?.innerText || "").slice(0, 20000);

  return {
    url,
    title,
    text: pageText,
    product: {
      name,
      color,
      price,
      currency
    },
    debugPrice: {
      from: ld?.price != null ? "jsonld" : meta?.price != null ? "meta" : dom?.price != null ? "dom" : "none",
      ld,
      meta,
      domRaw: dom?.raw || null
    }
  };
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === "SDF_GET_PAGE_DATA") {
    const data = getStructuredProduct();
    sendResponse({
      url: data.url,
      title: data.title,
      text: data.text,
      product: data.product,
      debugPrice: data.debugPrice
    });
  }
});