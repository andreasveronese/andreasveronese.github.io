const subtitleEl = document.getElementById("subtitle");
const btn = document.getElementById("analyzeBtn");

const productCard = document.getElementById("productCard");
const productNameEl = document.getElementById("productName");
const scorePillEl = document.getElementById("scorePill");
const productMetaEl = document.getElementById("productMeta");
const verdictRowEl = document.getElementById("verdictRow");
const verdictEl = document.getElementById("verdict");
const verdictHintEl = document.getElementById("verdictHint");
const chipsEl = document.getElementById("chips");

const altsCard = document.getElementById("altsCard");
const altsCountEl = document.getElementById("altsCount");
const altsEl = document.getElementById("alts");

const errorCard = document.getElementById("errorCard");
const errorTextEl = document.getElementById("errorText");

const debugCard = document.getElementById("debugCard");
const rawEl = document.getElementById("raw");
const toggleRawBtn = document.getElementById("toggleRawBtn");

toggleRawBtn.addEventListener("click", () => {
  const hidden = rawEl.hasAttribute("hidden");
  if (hidden) rawEl.removeAttribute("hidden");
  else rawEl.setAttribute("hidden", "");
});

function setStatus(text) {
  subtitleEl.textContent = text;
}

function setBusy(isBusy) {
  btn.disabled = isBusy;
  btn.textContent = isBusy ? "Analyzing…" : "Analyze";
}

function hideAll() {
  productCard.setAttribute("hidden", "");
  altsCard.setAttribute("hidden", "");
  errorCard.setAttribute("hidden", "");
  debugCard.setAttribute("hidden", "");
  verdictRowEl.setAttribute("hidden", "");
  rawEl.setAttribute("hidden", "");
}

function money(price, currency) {
  if (price == null || Number.isNaN(price)) return null;
  try {
    return new Intl.NumberFormat("sv-SE", {
      style: "currency",
      currency: currency || "SEK"
    }).format(price);
  } catch {
    return `${price} ${currency || ""}`.trim();
  }
}

function scoreBg(score) {
  if (score >= 75) return "rgba(61,220,151,0.20)";
  if (score >= 55) return "rgba(255,209,102,0.18)";
  return "rgba(255,92,122,0.18)";
}

function verdictStyle(v) {
  if (v === "BUY") return { bg: "rgba(61,220,151,0.20)", text: "BUY" };
  if (v === "CONSIDER") return { bg: "rgba(255,209,102,0.18)", text: "CONSIDER" };
  return { bg: "rgba(255,92,122,0.18)", text: v || "SKIP" };
}

function metaRow(key, val) {
  const row = document.createElement("div");
  row.className = "metaRow";
  const k = document.createElement("div");
  k.className = "metaKey";
  k.textContent = key;
  const v = document.createElement("div");
  v.className = "metaVal";
  v.title = typeof val === "string" ? val : "";
  v.textContent = val ?? "—";
  row.appendChild(k);
  row.appendChild(v);
  return row;
}

function chip(text) {
  const el = document.createElement("div");
  el.className = "chip";
  el.textContent = text;
  return el;
}

function isValidHttpUrl(u) {
  if (typeof u !== "string") return false;
  const s = u.trim();
  return s.startsWith("http://") || s.startsWith("https://");
}

function altCard(alt) {
  const box = document.createElement("div");
  box.className = "alt";

  const top = document.createElement("div");
  top.className = "altTop";

  const h = document.createElement("h3");
  h.className = "altTitle";

  const a = document.createElement("a");
  a.className = "altLink";
  a.textContent = alt.title || "Alternativ";

  const url = typeof alt.url === "string" ? alt.url.trim() : "";

  // ✅ Endast klickbar om url är giltig
  if (isValidHttpUrl(url)) {
    a.href = url;
    a.target = "_blank";
    a.rel = "noreferrer noopener";
  } else {
    // gör den inte klickbar (så vi slipper chrome-extension://.../null)
    a.removeAttribute("href");
    a.style.cursor = "default";
    a.style.textDecoration = "none";
    a.title = "Saknar giltig länk från sökresultat";
  }

  h.appendChild(a);

  const rel = document.createElement("div");
  rel.className = "badge";
  rel.textContent = `Relevans: ${alt.relevance ?? "—"}`;

  top.appendChild(h);
  top.appendChild(rel);

  const meta = document.createElement("div");
  meta.className = "altMeta";

  const retailer = document.createElement("span");
  retailer.className = "badge";
  retailer.textContent = alt.retailer || "Okänd butik";

  const price = document.createElement("span");
  price.className = "badge";
  price.textContent =
    alt.price != null ? (money(alt.price, alt.currency) || `${alt.price}`) : (alt.priceText || "Pris: —");

  meta.appendChild(retailer);
  meta.appendChild(price);

  const reason = document.createElement("div");
  reason.className = "reason";
  reason.textContent = alt.reason || "";

  // (valfritt) visa url som liten text om den finns, bra för debugging
  let urlLine = null;
  if (url) {
    urlLine = document.createElement("div");
    urlLine.className = "muted";
    urlLine.style.fontSize = "11px";
    urlLine.style.wordBreak = "break-word";
    urlLine.textContent = url;
  }

  box.appendChild(top);
  box.appendChild(meta);
  if (reason.textContent) box.appendChild(reason);
  if (urlLine) box.appendChild(urlLine);

  return box;
}

async function ensureContentScript(tabId) {
  await chrome.scripting.executeScript({
    target: { tabId },
    files: ["content.js"]
  });
}

function renderResult(data) {
  hideAll();

  debugCard.removeAttribute("hidden");
  rawEl.textContent = JSON.stringify(data, null, 2);

  const p = data?.product || {};
  const a = data?.analysis || {};
  const alts = Array.isArray(data?.alternatives) ? data.alternatives : [];

  productCard.removeAttribute("hidden");
  productNameEl.textContent = p.name || "Produkt";

  const score = Number(a.dealScore);
  scorePillEl.textContent = Number.isFinite(score) ? `Score: ${score}/100` : "Score: —";
  scorePillEl.style.background = scoreBg(Number.isFinite(score) ? score : 0);

  productMetaEl.innerHTML = "";
  const priceText = p.price != null ? (money(p.price, p.currency) || `${p.price}`) : "—";
  productMetaEl.appendChild(metaRow("Pris", priceText));
  if (p.brand) productMetaEl.appendChild(metaRow("Märke", p.brand));
  if (p.category) productMetaEl.appendChild(metaRow("Kategori", p.category));

  if (a.verdict) {
    verdictRowEl.removeAttribute("hidden");
    const vs = verdictStyle(a.verdict);
    verdictEl.textContent = vs.text;
    verdictEl.style.background = vs.bg;
    verdictHintEl.textContent =
      (Array.isArray(a.highlights) && a.highlights[0]) ? a.highlights[0] : "";
  }

  chipsEl.innerHTML = "";
  const highlights = Array.isArray(a.highlights) ? a.highlights : [];
  const risks = Array.isArray(a.risks) ? a.risks : [];
  for (const h of highlights.slice(0, 4)) chipsEl.appendChild(chip(`✅ ${h}`));
  for (const r of risks.slice(0, 3)) chipsEl.appendChild(chip(`⚠️ ${r}`));

  altsCard.removeAttribute("hidden");
  altsCountEl.textContent = `${alts.length} st`;
  altsEl.innerHTML = "";

  if (!alts.length) {
    const empty = document.createElement("div");
    empty.className = "muted";
    empty.textContent =
      "Inga alternativ hittades. Om du vet att SerpAPI fungerar: testa annan produkt eller kontrollera debug i rådata.";
    altsEl.appendChild(empty);
  } else {
    for (const alt of alts) altsEl.appendChild(altCard(alt));
  }
}

function renderError(msg) {
  hideAll();
  errorCard.removeAttribute("hidden");
  debugCard.removeAttribute("hidden");
  errorTextEl.textContent = msg || "Okänt fel";
  rawEl.textContent = "";
}

btn.addEventListener("click", async () => {
  setBusy(true);
  setStatus("Collecting page data…");

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) throw new Error("No active tab");

    await ensureContentScript(tab.id);

    const page = await chrome.tabs.sendMessage(tab.id, { type: "SDF_GET_PAGE_DATA" });

    setStatus("Analyzing…");

    const result = await chrome.runtime.sendMessage({
      type: "SDF_ANALYZE_PAGE",
      ...page
    });

    if (!result?.ok) throw new Error(result?.error || "Unknown error");

    setStatus("Done");
    renderResult(result.data);
  } catch (e) {
    setStatus("Error");
    renderError(e?.message || String(e));
  } finally {
    setBusy(false);
  }
});