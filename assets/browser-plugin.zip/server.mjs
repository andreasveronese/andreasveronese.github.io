import express from "express";
import cors from "cors";
import OpenAI from "openai";

const app = express();
const PORT = 3333;

app.use(cors({ origin: "*" }));
app.use(express.json({ limit: "2mb" }));

app.get("/", (req, res) => {
  res.send(`SERVER OK: SDF_ALT_SERVER_3333_v9 http://localhost:${PORT}`);
});

function mustEnv(name) {
  const v = process.env[name];
  if (!v) throw new Error(`${name} saknas. Exportera den innan du startar servern.`);
  return v;
}

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

function safeJsonParse(s) {
  try { return JSON.parse(s); } catch { return null; }
}

function clamp(n, a, b) {
  return Math.max(a, Math.min(b, n));
}

// Rensar titlar så queries inte blir “OCEAN Loose Straight Jeans – Blå – Men – ARKET SE women”
function normalizeTitle(title) {
  if (!title) return "";
  let t = String(title);

  // byt konstiga streck till vanliga och trimma
  t = t.replace(/[–—]/g, "-").replace(/\s+/g, " ").trim();

  // om titel innehåller |, ta bort sista delen (ofta varumärke)
  const pipeParts = t.split("|").map(s => s.trim()).filter(Boolean);
  if (pipeParts.length >= 2) pipeParts.pop();
  t = pipeParts.join(" ");

  // om titel innehåller " - " (från ARKET/HM etc), ta bara första 1–2 delarna
  const dashParts = t.split(" - ").map(s => s.trim()).filter(Boolean);
  if (dashParts.length >= 2) {
    // behåll första två delarna max (produkt + färg)
    t = dashParts.slice(0, 2).join(" ");
  }

  // ta bort butikssuffix som “ARKET SE”, “Men”, “Women” om de ligger som egna ord i slutet
  t = t.replace(/\b(arket|hm|h&m|asket|se|sweden|sverige)\b/gi, "").trim();
  t = t.replace(/\s+/g, " ").trim();

  return t;
}

function guessCategory(titleNorm) {
  const s = (titleNorm || "").toLowerCase();
  if (s.includes("jeans")) return "jeans";
  if (s.includes("t-shirt") || s.includes("t shirt")) return "t-shirt";
  if (s.includes("shirt")) return "shirt";
  if (s.includes("hoodie")) return "hoodie";
  if (s.includes("sweater") || s.includes("jumper")) return "sweater";
  if (s.includes("jacket")) return "jacket";
  if (s.includes("coat")) return "coat";
  if (s.includes("dress")) return "dress";
  if (s.includes("trousers") || s.includes("pants")) return "pants";
  return "clothing";
}

function buildSafeQueries(title, product) {
  const t = normalizeTitle(title);
  const cat = guessCategory(t);
  const color = product?.color ? String(product.color).trim() : "";

  // Bredare, säkrare queries (så vi får resultat även om titel är udda)
  const base1 = [t, color].filter(Boolean).join(" ").trim();
  const base2 = [cat, color].filter(Boolean).join(" ").trim();

  return [
    base1,
    `${base1} ${cat}`.trim(),
    `${cat} ${color} similar`.trim(),
    `${cat} similar ${color}`.trim(),
    `${cat} ${color} buy online`.trim(),
    // extra bred fallback
    `${cat} ${color}`.trim(),
    `${cat} loose straight` // funkar bra för jeans etc även utan titel
  ].filter(Boolean);
}

async function serpSearch(params) {
  const key = mustEnv("SERPAPI_KEY");
  const url = new URL("https://serpapi.com/search.json");
  for (const [k, v] of Object.entries(params)) url.searchParams.set(k, String(v));
  url.searchParams.set("api_key", key);

  const r = await fetch(url.toString());
  const txt = await r.text();
  const data = safeJsonParse(txt);

  if (!r.ok) throw new Error(`SerpAPI HTTP ${r.status}: ${txt.slice(0, 200)}`);
  if (!data) throw new Error(`SerpAPI: kunde inte läsa JSON: ${txt.slice(0, 200)}`);
  if (data.error) throw new Error(`SerpAPI error: ${data.error}`);

  return data;
}

async function serpShopping(query, gl = "se", hl = "sv", num = 12) {
  return serpSearch({ engine: "google_shopping", q: query, gl, hl, num });
}

async function serpWeb(query, gl = "se", hl = "sv", num = 10) {
  return serpSearch({ engine: "google", q: query, gl, hl, num });
}

function normalizeShoppingItem(it) {
  return {
    title: it?.title ?? null,
    url: it?.link ?? null,
    retailer: it?.source ?? null,
    priceText: it?.price ?? null,
    price: typeof it?.extracted_price === "number" ? it.extracted_price : null,
    currency: it?.price?.includes("kr") ? "SEK" : null,
    thumbnail: it?.thumbnail ?? null
  };
}

function normalizeWebItem(it) {
  return {
    title: it?.title ?? null,
    url: it?.link ?? null,
    retailer: it?.source ?? it?.displayed_link ?? null,
    priceText: null,
    price: null,
    currency: null,
    thumbnail: it?.thumbnail ?? null
  };
}

function dedupeByUrl(items) {
  const seen = new Set();
  const out = [];
  for (const it of items) {
    const u = typeof it.url === "string" ? it.url.trim() : "";
    if (!u || seen.has(u)) continue;
    seen.add(u);
    out.push(it);
  }
  return out;
}

async function buildProfileWithAI({ title, text, product }) {
  const pageText = typeof text === "string" ? text.slice(0, 5000) : "";
  const prompt = `
Returnera ENDAST JSON:
{
  "profile": {
    "name": string,
    "category": string,
    "color": string|null,
    "fit": string|null,
    "material": string|null,
    "price": number|null,
    "currency": string|null
  }
}

Titel: ${title || ""}
Produkt (från sidan): ${JSON.stringify(product || {}, null, 2)}
Textutdrag: """${pageText}"""
`;

  const resp = await client.responses.create({
    model: "gpt-4o-mini",
    input: prompt
  });

  const parsed = safeJsonParse(resp.output_text || "");
  if (!parsed?.profile) {
    const t = normalizeTitle(title);
    return {
      profile: {
        name: product?.name || t || title || null,
        category: guessCategory(t),
        color: product?.color || null,
        fit: null,
        material: null,
        price: typeof product?.price === "number" ? product.price : null,
        currency: product?.currency || "SEK"
      }
    };
  }
  // stärk profilen med price från content om den finns
  if (typeof product?.price === "number") parsed.profile.price = product.price;
  if (product?.currency) parsed.profile.currency = product.currency;
  if (product?.color && !parsed.profile.color) parsed.profile.color = product.color;
  return parsed;
}

async function rankWithAI(profile, candidates) {
  const prompt = `
Ranka kandidaterna efter hur lika de är profilen. Returnera ENDAST JSON:
{"alternatives":[{"title":string,"url":string,"retailer":string|null,"price":number|null,"currency":string|null,"reason":string,"relevance":number}]}

Profil:
${JSON.stringify(profile, null, 2)}

Kandidater:
${JSON.stringify(candidates.slice(0, 16), null, 2)}
`;
  const resp = await client.responses.create({
    model: "gpt-4o-mini",
    input: prompt
  });

  const parsed = safeJsonParse(resp.output_text || "");
  const alts = parsed?.alternatives;
  if (!Array.isArray(alts) || !alts.length) return [];

  return alts
    .map(a => ({
      title: a.title || null,
      url: a.url || null,
      retailer: a.retailer || null,
      price: typeof a.price === "number" ? a.price : null,
      currency: a.currency || null,
      reason: a.reason || "",
      relevance: clamp(Number(a.relevance) || 0, 0, 100)
    }))
    .filter(a => typeof a.url === "string" && (a.url.startsWith("http://") || a.url.startsWith("https://")))
    .slice(0, 12);
}

function attachSavings(alts, basePrice) {
  if (typeof basePrice !== "number" || !Number.isFinite(basePrice)) return alts;
  return alts.map(a => {
    const p = a.price;
    if (typeof p !== "number" || !Number.isFinite(p)) {
      return { ...a, cheaper: null, savingsAbs: null, savingsPct: null };
    }
    const savingsAbs = basePrice - p;
    const savingsPct = basePrice > 0 ? (savingsAbs / basePrice) * 100 : null;
    return {
      ...a,
      cheaper: savingsAbs > 0,
      savingsAbs: Math.round(savingsAbs * 100) / 100,
      savingsPct: savingsPct != null ? Math.round(savingsPct * 10) / 10 : null
    };
  });
}

app.post("/analyze", async (req, res) => {
  try {
    mustEnv("OPENAI_API_KEY");
    mustEnv("SERPAPI_KEY");

    const { url, title, text, product, debugPrice } = req.body || {};
    const basePrice = typeof product?.price === "number" ? product.price : null;

    const profileObj = await buildProfileWithAI({ title, text, product });
    const profile = profileObj.profile;

    const queries = buildSafeQueries(title, product).slice(0, 7);

    const debug = {
      version: "v9",
      basePrice,
      debugPriceFromContent: debugPrice?.from || null,
      normalizedTitle: normalizeTitle(title),
      queries,
      shopping: [],
      web: [],
      shoppingRawCount: 0,
      webRawCount: 0,
      finalCandidates: 0,
      usedWebFallback: false,
      queryErrors: []
    };

    // 1) Shopping: kör flera queries och IGNORERA fel per query
    const shoppingRaw = [];
    for (const q of queries) {
      try {
        const data = await serpShopping(q, "se", "sv", 12);
        const results = Array.isArray(data?.shopping_results) ? data.shopping_results : [];
        debug.shopping.push({ q, n: results.length });
        for (const it of results) shoppingRaw.push(normalizeShoppingItem(it));
      } catch (e) {
        debug.queryErrors.push({ q, where: "shopping", error: e?.message || String(e) });
      }
    }
    debug.shoppingRawCount = shoppingRaw.length;

    let candidates = dedupeByUrl(shoppingRaw).filter(it => it.url && it.url !== url);

    // 2) Om shopping gav 0 kandidater: fallback till vanlig Google-webb
    if (candidates.length === 0) {
      debug.usedWebFallback = true;
      const webRaw = [];
      for (const q of queries.slice(0, 5)) {
        try {
          const data = await serpWeb(q, "se", "sv", 10);
          const organic = Array.isArray(data?.organic_results) ? data.organic_results : [];
          debug.web.push({ q, n: organic.length });
          for (const it of organic) webRaw.push(normalizeWebItem(it));
        } catch (e) {
          debug.queryErrors.push({ q, where: "web", error: e?.message || String(e) });
        }
      }
      debug.webRawCount = webRaw.length;
      candidates = dedupeByUrl(webRaw).filter(it => it.url && it.url !== url);
    }

    debug.finalCandidates = candidates.length;

    // 3) Ranka med AI (om det finns kandidater)
    let alternatives = [];
    if (candidates.length) {
      try {
        alternatives = await rankWithAI(profile, candidates);
      } catch (e) {
        // Om AI failar: fallback = top 8 direkt
        alternatives = [];
        debug.queryErrors.push({ q: "(rank)", where: "openai", error: e?.message || String(e) });
      }
    }

    // 4) Fallback: om AI gav 0 men vi har kandidater → visa top 8 direkt
    if (!alternatives.length && candidates.length) {
      alternatives = candidates.slice(0, 8).map((c, i) => ({
        title: c.title,
        url: c.url,
        retailer: c.retailer,
        price: c.price ?? null,
        currency: c.currency ?? null,
        reason: debug.usedWebFallback
          ? "Hittad via vanlig Google-sökning (fallback)."
          : "Hittad via Google Shopping-sökning (fallback).",
        relevance: 60 - i
      }));
    }

    // 5) Savings + sortera billigare först om basePrice finns
    alternatives = attachSavings(alternatives, basePrice);
    if (basePrice != null) {
      alternatives.sort((a, b) => {
        const ac = a.cheaper === true ? 0 : a.cheaper === false ? 1 : 2;
        const bc = b.cheaper === true ? 0 : b.cheaper === false ? 1 : 2;
        if (ac !== bc) return ac - bc;
        return (b.relevance || 0) - (a.relevance || 0);
      });
    }
    alternatives = alternatives.slice(0, 8);

    res.json({
      ok: true,
      url: url || null,
      title: title || null,
      product: profile,
      analysis: {
        dealScore: alternatives.length ? 70 : 50,
        verdict: alternatives.length ? "CONSIDER" : "SKIP",
        highlights: alternatives.length
          ? ["Hittade alternativ även om vissa queries inte gav resultat."]
          : ["Inga resultat. Testa annan produkt eller kontrollera queries i debug."],
        risks: ["Pris kan variera med storlek/land. Dubbelkolla frakt och returer."],
        nextActions: ["Öppna alternativen och jämför pris + likhet."]
      },
      alternatives,
      debug
    });
  } catch (e) {
    // Viktigt: returnera tydligt fel, men utan att dö i extensionen med ok:false i text
    res.status(200).json({ ok: false, error: e?.message || String(e) });
  }
});

app.listen(PORT, () => {
  console.log(`SERVER OK: SDF_ALT_SERVER_3333_v9 http://localhost:${PORT}`);
});